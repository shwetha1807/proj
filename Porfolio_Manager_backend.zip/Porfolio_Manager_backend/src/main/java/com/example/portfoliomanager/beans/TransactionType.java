package com.example.portfoliomanager.beans;

public enum TransactionType {
    BUY,
    SELL
}
